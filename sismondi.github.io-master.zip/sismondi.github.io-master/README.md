# Sismondi.github.io

Site géré par Estel, Gaëtan et Jan

[***ACCEDER AU SITE***](http://sismondi.github.io/)

## Description du travail

Créer un site à l'aide de Github où l'on peut poser des questions et y répondre.

## Caractéristiques

- [x] Interface
- [x] Live-Rendering des questions  (21 Mai)
- [x] Gestion des questions         (17 Mai)
- [x] Gestion de comptes            (17 Mai)

## Répartition du travail

Personne | Tâche | Description | Branche | Version
------- | ----------- | --- | ------------- | -------
Gaëtan | Code | Vue.js, JS & PouchDB | Gu | 0.0.1
Estel | Design | HTML & CSS | Estel | 0.0.1
Jan | Design | HTML & CSS | Jan | 0.1.0

## Technologies utilisées

:star: Vue

:star: PouchDB
