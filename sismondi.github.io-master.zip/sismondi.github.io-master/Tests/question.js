 
var app = new Vue({
  el: '#app',
  data: {
   q : {
    "UUID" : 327654925987326548265843563295043,
    "title" : "Conjuguer",
    "content" : "Verbe être en allemand au présent svp",
    "option" : "Allemand",
    "spec" : "DF",
    "year" : "1ère année",
    "date" : "10.05.2017 11:15",
   }
  }
})

